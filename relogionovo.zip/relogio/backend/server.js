const express = require('express');
const cors = require('cors');
require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const app = express();
const PORT = process.env.PORT || 3000;

// O nome da nova tabela
const TABELA = 'relojoaria_produtos';

// Middleware
app.use(cors());
app.use(express.json());

// Inicializar Supabase
// Mantenha as chaves do .env (SUPABASE_URL e SUPABASE_KEY)
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);

// Rota teste
app.get('/', (req, res) => {
  res.json({ mensagem: 'API rodando na tabela: ' + TABELA });
});

// --- Rota de Leitura (GET) ---

// GET - Buscar todos os produtos
app.get('/produtos', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from(TABELA) // Alterado para 'relojoaria_produtos'
      .select('*');
    if (error) throw error;
    res.json(data);
  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
});

// GET - Buscar produto por ID
app.get('/produtos/:id', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from(TABELA) // Alterado para 'relojoaria_produtos'
      .select('*')
      .eq('id', req.params.id)
      .single();

    // Adição de tratamento para 404 (Produto não encontrado)
    if (error && error.code === 'PGRST116') {
      return res.status(404).json({ erro: 'Produto não encontrado.' });
    }
    if (error) throw error;

    res.json(data);
  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
});

// --- Rota de Criação (POST) ---

// POST - Criar novo produto
app.post('/produtos', async (req, res) => {
  try {
    // Campos atualizados para corresponder à nova tabela
    const { name, description, emoji, price, stock } = req.body; 

    // Opcional: Adicionar validação básica para campos obrigatórios
    if (!name || typeof price !== 'number' || price < 0) {
        return res.status(400).json({ 
            erro: 'Nome e Preço (positivo) são obrigatórios.' 
        });
    }

    const { data, error } = await supabase
      .from(TABELA) // Alterado para 'relojoaria_produtos'
      .insert([{ name, description, emoji, price, stock }])
      .select();
      
    if (error) throw error;
    res.status(201).json(data); // Usar status 201 para "Created"
  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
});

// --- Rota de Atualização (PUT) ---

// PUT - Atualizar produto
app.put('/produtos/:id', async (req, res) => {
  try {
    // Campos atualizados para corresponder à nova tabela
    const { name, description, emoji, price, stock } = req.body;

    const { data, error } = await supabase
      .from(TABELA) // Alterado para 'relojoaria_produtos'
      // Passa apenas os campos presentes no body para atualização
      .update({ name, description, emoji, price, stock }) 
      .eq('id', req.params.id)
      .select();
      
    if (error) throw error;
    res.json(data);
  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
});

// --- Rota de Deleção (DELETE) ---

// DELETE - Deletar produto
app.delete('/produtos/:id', async (req, res) => {
  try {
    const { error } = await supabase
      .from(TABELA) // Alterado para 'relojoaria_produtos'
      .delete()
      .eq('id', req.params.id);
      
    if (error) throw error;
    res.json({ mensagem: 'Produto deletado' });
  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});